package com.example.helloworld;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final String TAG= MainActivity.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.e("TAG", "Creating the URI....");
        Log.d("MainActivity", "Happy Birthday to Hannah");
        Log.e("MainActivity", "errorHello");
        Log.w("MainActivity", "warnHello");
        Log.i("MainActivity", "MainActivity layout is complete");
//        Log.e("MainActivity", "Happy Birthday to");
    }

}